package universidades.Nelson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NelsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
