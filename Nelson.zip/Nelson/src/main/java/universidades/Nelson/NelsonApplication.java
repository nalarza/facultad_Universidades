package universidades.Nelson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NelsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(NelsonApplication.class, args);
	}

}
